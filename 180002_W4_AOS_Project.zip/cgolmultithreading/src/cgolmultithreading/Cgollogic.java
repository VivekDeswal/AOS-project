
package cgolmultithreading;

public class Cgollogic extends Thread{

	private int k, l;
	private int arr[][] ;
	private int nextstage[][]=new int [100][100];
	
	public Cgollogic(int k, int l, int arr[][] ) {
		this.k=k;
		this.l=l;
		this.arr = arr;
	}
	

	public void run() {
		long startTime = System.nanoTime();
		int i,j,x,y;

		// Loop through every cell of the every row and column
		for(i=1; i<k-1; i++){
			for(j=1; j<l-1; j++){

				// Find how many cells are alive
				int alive = 0;
				for(x=-1; x<=1; x++)
					for(y=-1; y<=1; y++)
						alive = alive + arr[i+x][j+y];

				alive = alive - arr[i][j];

				// If cell is lonely then it dies
				if((arr[i][j] == 1) && (alive < 2)){
					nextstage[i][j] = 0;
				}

				// If cell is over populated it dies
				else if((arr[i][j] == 1) && (alive > 3)){
					nextstage[i][j] = 0;
				}

				// A new cell is born as 3 adjacent cells are alive
				else if((arr[i][j] == 0) && (alive ==3)){
					nextstage[i][j] = 1;
				}

				// Nothing happens so it remains same
				else{
					nextstage[i][j] = arr[i][j];
				}
			}
		}

		System.out.println();;
		System.out.println("Next Stage is:");

		// Printing the next life
		for(x=0; x<k; x++){
			for(y=0; y<l; y++){
				System.out.print(nextstage[x][y] + " ");
			}
			System.out.println();
		}
		
		//Assigning the next stage to the main array to print further stages 

		for (x = 0; x < k; x++) {
			for (y = 0; y < l; y++) {
				arr[x][y] = nextstage[x][y];
			}
		}
		
		long execuationtime = System.nanoTime() - startTime;
        System.out.println("Time taken to generate next level: " + execuationtime + " ns");
        System.out.println("Enter the yes for getting the next level else enter no for stopping the game: \n");
	}

}	